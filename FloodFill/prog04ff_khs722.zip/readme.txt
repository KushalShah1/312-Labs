1. Unzip the folder
2. Navigate to the folder in Linux
3. Type in make to compile the program
4. To run the program type:
	./flood_fill <Filename.txt>

ex:	./flood_fill fake_picture.txt 